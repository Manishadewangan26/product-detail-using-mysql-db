from django.shortcuts import render
from product.models import Product

# Create your views here.
def home_views(request):
    if request.method=='POST':
        name=request.POST['name']
        weight=request.POST['weight']
        price=request.POST['price']
        home_views = Product(name=name,weight=weight,price=price)
        home_views.save()


    return render (request,'product/home.html')


def detail_view(request):
    add_display=Product.objects.all()
    return render(request,'product/details.html',{'add_display':add_display})
